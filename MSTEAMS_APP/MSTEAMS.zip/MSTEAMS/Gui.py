from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

class window(QMainWindow):
    def __init__(self):
        super().__init__()
